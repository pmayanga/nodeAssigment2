exports.posts = require ('./posts.js')
exports.comments = require ('./comments.js')