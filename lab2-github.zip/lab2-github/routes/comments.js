let store = {
  posts: [
    {name: 'Top 10 ES6 Features every Web Developer must know',
    url: 'https://webapplog.com/es6',
    text: 'This essay will give you a quick introduction to ES6. If you don’t know what is ES6, it’s a new JavaScript implementation.',
    comments: [
      {text: 'Cruel…..var { house, mouse} = No type optimization at all'},
      {text: 'I think you’re undervaluing the benefit of ‘let’ and ‘const’.'},
      {text: '(p1,p2)=>{ … } ,i understand this ,thank you !'}      
    ]
    }
  ]
}

module.exports = {
  getComments(req, res) {
  	if (!req.params.postId)  return res.status(400).send('An id is required')
    if (isNaN(req.params.postId))  return res.status(400).send('The post id must be numeric')
    if (req.params.postId >= store.posts.length)  return res.status(400).send('Invalid Id')
  	let idPost = req.params.postId
  	res.status(200).send(store.posts[idPost].comments)  
  }, 

  addComment(req, res) {
  	if (!req.params.postId)  return res.status(400).send('An id is required')
    if (isNaN(req.params.postId))  return res.status(400).send('The post id must be numeric')
    if (req.params.postId >= store.posts.length)  return res.status(400).send('Invalid Id')
  	let newComments = req.body  
  	let id = store.posts.length
  	store.posts[req.params.postId].comments.push(newComments)
  	res.status(201).send({id: id})
  },

  updateComment(req, res) {
  	if (!req.params.postId)  return res.status(400).send('An id is required')
    if (isNaN(req.params.postId))  return res.status(400).send('The post id must be numeric')
    if (req.params.postId >= store.posts.length)  return res.status(400).send('Invalid Id')
    console.log('Req.body')
    let upComment = req.body  
	console.log(req.body)
	store.posts[req.params.postId].comments[req.params.commentId]=upComment
	res.status(201).send(store.posts[req.params.postId].comments)  
  },

  removeComment(req, res) {
  	if (!req.params.postId)  return res.status(400).send('An id is required')
    if (isNaN(req.params.postId))  return res.status(400).send('The post id must be numeric')
    if (req.params.postId >= store.posts.length)  return res.status(400).send('Invalid Id')
    store.posts[req.params.postId].comments.splice(req.params.commentId,1)
	res.status(201).send(store.posts[req.params.postId].comments)  
  }  
}