module.exports = {

  getPosts(req, res) {
  	res.status(200).send(req.store.posts)
  },

  addPost(req, res) {
  	let reqBody = req.body
  	let newPost={}
  	newPost.name = reqBody.name
    newPost.url = reqBody.url
    newPost.text = reqBody.text
    newPost.comments = reqBody.comments  
  	let id = req.store.posts.length
  	console.log(newPost)
  	req.store.posts.push(newPost)
  	res.status(201).send({id: id})
  },

  updatePost(req, res) {
  	let reqBody = req.body
  	let upPost={}
  	upPost.name = reqBody.name
    upPost.url = reqBody.url
    upPost.text = reqBody.text
    upPost.comments = reqBody.comments
  	req.store.posts[req.params.id] = upPost
  	res.status(200).send(req.store.posts[req.params.id])
  },

  removePost(req, res) {
  	req.store.posts.splice(req.params.id, 1)
  	res.status(204).send()
  }

}