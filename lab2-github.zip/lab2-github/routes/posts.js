let store = {
  posts: [
    {name: 'Top 10 ES6 Features every Web Developer must know',
    url: 'https://webapplog.com/es6',
    text: 'This essay will give you a quick introduction to ES6. If you don’t know what is ES6, it’s a new JavaScript implementation.',
    comments: [
      {text: 'Cruel…..var { house, mouse} = No type optimization at all'},
      {text: 'I think you’re undervaluing the benefit of ‘let’ and ‘const’.'},
      {text: '(p1,p2)=>{ … } ,i understand this ,thank you !'}      
    ]
    }
  ]
}


module.exports = {
  getPosts(req, res) {
  	res.status(200).send(store.posts)
  },

  addPost(req, res) {
  	let reqBody = req.body
  	let newPost={}
  	newPost.name = reqBody.name
    newPost.url = reqBody.url
    newPost.text = reqBody.text
    newPost.comments = reqBody.comments  
  	let id = store.posts.length
  	console.log(newPost)
  	store.posts.push(newPost)
  	res.status(201).send({id: id})
  },

  updatePost(req, res) {
  	if (!req.params.id)  return res.status(400).send('An id is required')
    if (req.params.id >= store.posts.length)  return res.status(400).send('Invalid Id')
  	let reqBody = req.body
  	let upPost={}
  	upPost.name = reqBody.name
    upPost.url = reqBody.url
    upPost.text = reqBody.text
    upPost.comments = reqBody.comments
  	store.posts[req.params.id] = upPost
  	res.status(200).send(store.posts[req.params.id])
  },

  removePost(req, res) {
  	if (!req.params.id)  return res.status(400).send('An id is required')
    if (req.params.id >= store.posts.length)  return res.status(400).send('Invalid Id')
  	store.posts.splice(req.params.id, 1)
  	res.status(204).send()
  }

}