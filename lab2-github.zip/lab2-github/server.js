const routes = require('./routes') 
const express = require('express') 
const logger = require('morgan')
const errorhandler = require('errorhandler')
const bodyParser = require('body-parser')

let app = express()
app.use(bodyParser.json())
app.use(logger('dev'))
app.use(errorhandler())

//GET /posts
app.get('/posts', (req, res) => {
  	routes.posts.getPosts(req, res)
})

//POST /posts
app.post('/posts', (req, res) => {
	routes.posts.addPost(req, res)
})

//PUT /posts
app.put('/posts/:id', (req, res) => {
  	routes.posts.updatePost(req, res)
})

//DELETE /posts
app.delete('/posts/:id', (req, res) => {
  	routes.posts.removePost(req, res)
})

//GET /posts/:postId/comments
app.get('/posts/:postId/comments', (req, res) => {
  	routes.comments.getComments(req, res)
})

//POST /posts/:postId/comments
app.post('/posts/:postId/comments', (req, res) => {
  	routes.comments.addComment(req, res)
})

//PUT  /posts/:postId/comments/commentId
app.put('/posts/:postId/comments/:commentId', (req, res) => {
  	routes.comments.updateComment(req, res)
})

//DELETE /posts/:postId/comments/commentId
app.delete('/posts/:postId/comments/:commentId', (req, res) => {
  	routes.comments.removeComment(req, res)
})

//RUNS the server
app.listen(3000)
console.log('Server listening at port 3000')
