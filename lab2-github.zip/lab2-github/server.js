const routes = require('./routes') 
const express = require('express') 
const logger = require('morgan')
const errorhandler = require('errorhandler')
const bodyParser = require('body-parser')

let store = {
  posts: [
    {name: 'Top 10 ES6 Features every Web Developer must know',
    url: 'https://webapplog.com/es6',
    text: 'This essay will give you a quick introduction to ES6. If you don’t know what is ES6, it’s a new JavaScript implementation.',
    comments: [
      {text: 'Cruel…..var { house, mouse} = No type optimization at all'},
      {text: 'I think you’re undervaluing the benefit of ‘let’ and ‘const’.'},
      {text: '(p1,p2)=>{ … } ,i understand this ,thank you !'}      
    ]
    }
  ]
}


let app = express()
app.use(bodyParser.json())
app.use(logger('dev'))
app.use(errorhandler())

app.use((req,res,next)=>{	
	req.store = store
	next()	
})

function validateIds(postId, commentId){
	if (isNaN(postId))  return "The post id must be numeric"
    if (postId >= store.posts.length)  return "Invalid post id"
	if (isNaN(commentId))  return "The comment id must be numeric"
    if (commentId >= store.posts[postId].comments.length && commentId!=0)  return "Invalid comment id"
	return ""
}

/*******************************************/
/******************* POSTS *****************/
/******************************************/
//GET /posts
app.get('/posts', (req, res) => {
  	routes.posts.getPosts(req, res)
})

//POST /posts
app.post('/posts', (req, res) => {
	routes.posts.addPost(req, res)
})

//PUT /update post
app.put('/posts/:id', (req, res) => {
	if (req.params.id){
		let msg = validateIds(req.params.id, 0)
		if (msg==""){
			routes.posts.updatePost(req, res)
		}
		else{
			return res.status(400).send(msg)
		}
	}
	else{
		return res.status(400).send('A post id is required')
	}
})

//DELETE /post
app.delete('/posts/:id', (req, res) => {
	if (req.params.id){
		let msg = validateIds(req.params.id, 0)
		if (msg==""){
			routes.posts.removePost(req, res)
		}
		else{
			return res.status(400).send(msg)
		}
	}
	else{
		return res.status(400).send('A post id is required')
	}
})

/********************************************/
/******************* COMMENTS ***************/
/********************************************/
//GET /posts/:postId/comments
app.get('/posts/:postId/comments', (req, res) => {
	let msg = validateIds(req.params.postId, 0)
	if (msg==""){
		routes.comments.getComments(req, res)
	}
	else{
		return res.status(400).send(msg)
	}
})

//POST /posts/:postId/comments
app.post('/posts/:postId/comments', (req, res) => {
	let msg = validateIds(req.params.postId, 0)
	if (msg==""){
		routes.comments.addComment(req, res)
	}
	else{
		return res.status(400).send(msg)
	}  	
})

//PUT  /posts/:postId/comments/commentId
app.put('/posts/:postId/comments/:commentId', (req, res) => {
	let msg = validateIds(req.params.postId, req.params.commentId)
	if (msg==""){
		routes.comments.updateComment(req, res)
	}
	else{
		return res.status(400).send(msg)
	}  	 	
})

//DELETE /posts/:postId/comments/commentId
app.delete('/posts/:postId/comments/:commentId', (req, res) => {
	let msg = validateIds(req.params.postId, req.params.commentId)
	if (msg==""){
		routes.comments.removeComment(req, res)
	}
	else{
		return res.status(400).send(msg)
	}  	 
})

//RUNS the server
app.listen(3000)
console.log('Server listening at port 3000')
